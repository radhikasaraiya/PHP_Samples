<?php   
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "firstsample";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


$pub_lang = $_POST['pub_lang'];
 
$sql = "select * from book_mast where pub_lang LIKE '$pub_lang%'";
//echo $sql;
$res = mysqli_query($conn,$sql);
echo "<option>Book Title</option>";
while($row=mysqli_fetch_array($res))
{
echo "<option>".$row['book_name']."</option>";
}

?>
