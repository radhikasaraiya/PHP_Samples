<?php   
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "firstsample";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


$pub_lang = $_POST['pub_lang'];
 
$sql = "select * from book_mast where pub_lang LIKE '$pub_lang%'";
//echo $sql;
$res = mysqli_query($conn,$sql);
echo "<table border=1>";

echo "<tr>";
echo "<th>book_name</th>";
echo "<th>isbn_no</th>";
echo "<th>book_price</th>";
echo "<th>no_page</th>";
echo "</tr>";
while($row=mysqli_fetch_array($res))
{
echo "<tr>";
echo "<td>".$row['book_name']."</td>";
echo "<td>".$row['isbn_no']."</td>";
echo "<td>".$row['book_price']."</td>";
echo "<td>".$row['no_page']."</td>";
echo "</tr>";
}
echo "</table>";
?>
