<?php   
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "firstsample";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


$pname = $_POST['pname'];
//echo $pname;
$sql = "select book_name from book_mast where book_name LIKE '$pname%'";
//echo $sql;
$res = mysqli_query($conn,$sql);

while($row=mysqli_fetch_array($res))
{
echo "<p>".$row['book_name']."</p>";
}
?>
