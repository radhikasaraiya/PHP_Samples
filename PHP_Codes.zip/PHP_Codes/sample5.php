<?php
if (isset($_POST['s1']))
{
	$user=$_POST['t1'];
	$pass=$_POST['t2'];
	if ($user=="php" && $pass=="easy")
		header("Location:home.php");
	else
		echo "Sorry";
}
?>


<html>
<form method="post">
	<table border="0">
		<tr>
			<td>Login</td>
			<td><input type="text" name="t1"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="Password" name="t2"></td>
		</tr>
		<tr>
		
			<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
	</form>
</html>