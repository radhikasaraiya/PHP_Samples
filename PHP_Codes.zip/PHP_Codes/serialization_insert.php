<?php
include 'serialDB.php';

if(isset($_POST['s1']))
{
	$nm=$_POST['nm'];
	$sem=$_POST['sem'];

	$ar=array($nm,$sem);
	$sar=serialize($ar);

	$sql="insert into testTB values(0,'$sar')";
	$res=mysqli_query($con,$sql);

	if($res==1)
		echo "data inserted";

	else 
	  echo "Error:" . mysqli_error($con);

}
?>

<html>
<head>
</head>
<body>
	<form method="post">
Name:<input type="text" name="nm"><br><br>
Sem <input type="text" name="sem"><br><br>
<input type="submit" name="s1" value="Submit">
</form>
</body>
</html>