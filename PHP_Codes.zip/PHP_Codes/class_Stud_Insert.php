<?php
require_once("Class_Student.php");
if (isset($_POST['s1']))
{
	$sname=$_POST['t1'];
	$fees=$_POST['t2'];
	$course=$_POST['t3'];
	$s1=new Student(0,$sname,$fees,$course);
	$s1->Insert();
}

?>

<form method="post">
	<table border="0">
			<tr>
			<td>Student Name</td>
			<td><input type="text" name="t1"></td>
			</tr>

			<tr>
			<td>Fees</td>
			<td><input type="text" name="t2"></td>
			</tr>
			
			<tr>
				<td>course</td>
			<td><input type="text" name="t3"></td>
			</tr>

			<tr>
				
			<td><input type="submit" name="s1" value="submit"></td>
			</tr>

		</table>	
</form>