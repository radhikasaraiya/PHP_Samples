<?php
session_start();
$uname=$_SESSION["uname"];

echo "Hello $uname ";

?>
<body bgcolor="red">
	

</body>
