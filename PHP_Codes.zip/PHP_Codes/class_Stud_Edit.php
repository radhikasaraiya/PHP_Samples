<?php
require_once("Class_Student.php");
$rno="";
$sname="";
$fees="";
$course="";
if (isset($_POST['s1']))
{
	$rno=$_POST['t0'];
	$sname=$_POST['t1'];
	$fees=$_POST['t2'];
	$course=$_POST['t3'];
	$s1=new Student($rno,$sname,$fees,$course);
	$s1->Update();
}
if (isset($_REQUEST['erno']))
{
	$erno=$_REQUEST['erno'];
	$s1=new Student(0,"","","");
	$rec=$s1->Search($erno);
	print_r($rec);
	$rno=$rec['Rno'];
	$sname=$rec['SName'];
	$fees=$rec['Fees'];
	$course=$rec['Course'];
}
?>

<form method="post">
	<table border="0">
			<tr>
			<!-- <td>Student Rollno</td> -->
			<td><input type="hidden" name="t0" value="<?php echo $rno;?>"></td>
			</tr>


			<tr>
			<td>Student Name</td>
			<td><input type="text" name="t1"
				value="<?php echo $sname;?>"
				></td>
			</tr>

			<tr>
			<td>Sem</td>
			<td><input type="text" name="t2"
				value="<?php echo $fees;?>"
				></td>
			</tr>
			
			<tr>
				<td>course</td>
			<td><input type="text" name="t3"
				value="<?php echo $course;?>"
				></td>
			</tr>

			<tr>
				
			<td><input type="submit" name="s1" value="submit"></td>
			</tr>

		</table>	
</form>