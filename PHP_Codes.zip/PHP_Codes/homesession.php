<?php
session_start();
$uname=$_SESSION["uname"];

echo "Hello $uname ";
 
?>
<body bgcolor="cyan">
	

</body>
<a href="Page2.php">Page2</a>