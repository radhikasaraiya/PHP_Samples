<?php
$con=mysqli_connect("localhost","root","","firstsample"); //connection string 
$s1="select * from student";
	$res=mysqli_query($con,$s1);
	$data="";
	while($row=mysqli_fetch_array($res))
	{
		$data=$data.$row['Rno']."\t".$row['SName']."\t".$row['Course']."\t".$row['Fees']."\n";
	}
	echo $data;
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=Stud_Reoprt.xls");
?>
