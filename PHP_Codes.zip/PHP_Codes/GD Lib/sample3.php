<?php
header('content-type: image/png');
 
$image = imagecreate(300, 300);
 
$dark_grey = imagecolorallocate($image, 102, 102, 102);
$white = imagecolorallocate($image, 255, 255, 255);
 
$font_path = 'font/arial.ttf';
 
$string = 'Hello World!';
 
imagettftext($image, 50, -45, 30, 70, $white, $font_path, $string);
 
imagepng($image);
 
imagedestroy($image);
?>