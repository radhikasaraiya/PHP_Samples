<?php
header("Content-type: image/jpeg");
$data = array(30,24,45,23,56,66,16,80);
$sname=array("A","B","C","D","E","F","G","H");

$height = 255;
$width = 400;
$im = imagecreate($width,$height);
$white = imagecolorallocate($im,255,255,255);
$black = imagecolorallocate($im,0,0,0);
$red = imagecolorallocate($im,255,0,0);

imageline($im, 10, 5, 10, 230, $black);
imageline($im, 10, 230, 400, 230, $black);
 $x = 20;
 $y = 230;
 $x_width = 20;
 $y_ht = 30;
  for($i=0;$i<sizeof($data);$i++)
  {
  $color = imagecolorallocate($im,rand(0,255),rand(0,255),rand(0,255));
  imageFilledRectangle($im,$x,$y,$x+$x_width,$y-$data[$i],$color);
  imageRectangle($im,$x,$y,$x+$x_width,$y-$data[$i],$black);	
  imagestring($im,3,$x+5,$y,$sname[$i],$red);
  $x=$x+$x_width+20;
  }

imagejpeg($im);
imagedestroy($img);
?>