<?php
session_start(); 
 //    $data=rand(10000,99999);
 //    $ch1=rand(65,90);
 //    $ch2=rand(65,90);

 // if(isset($_SESSION['data']))
 // 	$str=$_SESSION['data'];

 // else
 // {
 // 	$str=chr($ch1).chr($ch2).$data;
 // 	$_SESSION['data']=$str;
 // }


if(isset($_POST['submit']))
{
	$data=$_POST['c1'];
	$uname=$_POST['t1'];
	echo $uname;
	$cap=$_SESSION['data'];

	if($data==$cap)
		echo"correct code";
	else
		echo "Incorrect code";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Captcha Code</title>
</head>
<body>
	<form method="post">
	<img src="Pro_captcha.php" height="100" width="100"><br/>
	UserName<input type="text" name="t1"><br/>
	<input type="text" name="c1" placeholder="type the Captcha code here"><br/>
	<input type="submit" name="submit" value="Click Here"><br/>
	</form>
</body>
</html>