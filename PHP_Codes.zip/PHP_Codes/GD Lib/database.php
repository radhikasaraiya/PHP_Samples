<?php
$con=mysqli_connect("localhost","root",""); //connection string -server,username,password
$db=mysqli_select_db($con,"student"); //selection of server-connection,name of db

if (!$con)
{
	die("Connection failed".mysqli_error());
}

if (!$db)
{
	die("Error in DataBase".mysqli_error());
}
?>