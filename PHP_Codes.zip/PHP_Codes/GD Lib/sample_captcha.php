<?php
session_start();
   $text="Hello World ...";
   $data=rand(10000,99999); 
   $ch1=rand(65,90);  //ascii value A-z
   $ch2=rand(65,90);
   //$str=chr($ch1).chr($ch2).$data;
   if (isset($_SESSION['data']))
   {
     $str=$_SESSION['data'];
   }
   
   else
   {
   $str=chr($ch1).chr($ch2).$data;
    
   }
   // Create an image with the specified dimensions
   $image = imageCreate(100,55);
 
    $color = imageColorAllocate($image, 200,200,200);
    // Create a color
    $colorBlue= imageColorAllocate($image, 0,0,255);
 
   // Draw the string
   imageString($image, 3, 10, 10, $str, $colorBlue);
 
   // Set type of image and send the output
   header("Content-type: image/jpeg");
   imageJpeg($image);
 
   // Release memory
   imageDestroy($image);
?>
