<?php
session_start();
//include_once("sample_captcha.php");
	$st="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$nst="";
	for($i=1;$i<=6;$i++)
	{
		$ch=rand(0,35);
		//substr($st, $ch,1)
		$nst=$nst.$st[$ch];
	}
	echo $nst."<br>";
   $data=rand(10000,99999);
   $ch1=rand(65,90);
   $ch2=rand(65,90);
   if (isset($_SESSION['data']))
   {
    $str=$_SESSION['data'];
   }
   else
   {
   $str=chr($ch1).chr($ch2).$data;
    $_SESSION['data']=$str;
   }

if (isset($_POST['s1']))
{
	$data=$_POST['t1'];
	$cap=$_SESSION['data'];
	if ($cap==$data)
		echo "Equal";
	else
		echo "Not Equal";
}


?>
<form method="post">
  <img src="sample_captcha.php" width="300" height="300">
  <input type="text" name="t1">
  <input type="submit" name="s1" value="submit">
  </form>