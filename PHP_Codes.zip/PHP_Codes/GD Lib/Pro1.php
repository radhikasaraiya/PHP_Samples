<?php
header('content-type:image/jpg');
$img=imagecreate(1000,300); //Create a new palette based image
$blue=imagecolorallocate($img, 0, 0, 255);  //always first defined color is for background only .Allocate a color for an image
$white=imagecolorallocate($img, 255, 255, 255);
imagestring($img, 5, 500, 150, 'Hinal Acharya', $white); // Draw a string horizontally

imagestringup($img, 5, 400,150, 'Hinal Acharya', $white);//draw string vertically.

imagepng($img); //Output a PNG image to either the browser or a file
imagedestroy($image); //frees any memory associated with image
?>
