<?php
session_start(); 
   $data=rand(10000,99999);
   $ch1=rand(65,90);
   $ch2=rand(65,90);

if(isset($_SESSION['data']))
	$str=$_SESSION['data'];

else
	{
		$str=chr($ch1).chr($ch2).$data;
		$_SESSION['data']=$str;
	}
$image=imageCreate(100,55);
$grey=imageColorAllocate($image,200,200,200);
$blue=imagecolorallocate($image, 0, 0, 255);
imageString($image,3,10,10,$str,$blue);
header("Content-type:image/jpeg");
imageJpeg($image);

?>

