<?php
header('content-type:image/png');
 
$image = imagecreate(400, 200);
 
$dark_grey = imagecolorallocate($image, 102, 102, 102);
$white = imagecolorallocate($image, 255, 255, 255);
 
//Set the path to our true type font 
$font_path = 'font/consola.ttf';
 
//Set our text string 
$string = 'Hello World!';
 //imagettftext(image, size, angle, x, y, color, fontfile, text)
imagettftext($image, 20, -10, 30, 30, $white, $font_path, $string);
imagepng($image);
 
imagedestroy($image);
?>