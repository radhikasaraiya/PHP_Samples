<?php
header('content-type: image/png');
//Create our basic image stream 
//125px width, 125px height
$image = imagecreate(500, 300);
 
$blue = imagecolorallocate($image, 0,0,255);
$red = imagecolorallocate($image, 120, 120, 0);
$x=10;
$y=200;
//imagestringup($image,10,$x,$y,"heloo..",$red);
imageString($image,4,$x,$y,"heloo..",$red);

$col2 = imagecolorallocate($image, 220, 120,220);
imageString($image,7,$x,100,"Good Day...",$col2);
imagepng($image);
 
imagedestroy($image);
?>