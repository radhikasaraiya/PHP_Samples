<?php
   // Create an image with the specified dimensions
   $image = imagecreatefromjpeg("shirt.jpg");
 
   // Create a color
   $colorYellow = imageColorAllocate($image, 255,255,255);
   $red= imageColorAllocate($image, 255,0,0);
   // Rotate
   
   $text="Hello World";
   // $data=rand(10000,99999);
   // $ch1=rand(65,90);
   // $ch2=rand(65,90);
   // $str=chr($ch1).chr($ch2).$data;
   //imageString()
   imageString($image,6,70,100,$text,$red);

   // $font_path = 'font/consola.ttf';
   // imagettftext($image, 10, -20, 70, 80, $red, $font_path, $text);

    header("Content-type: image/png");
   imagePng($image);
 
   imageDestroy($image);
?>