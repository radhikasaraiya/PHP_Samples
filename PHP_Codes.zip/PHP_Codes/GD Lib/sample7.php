<?php
   // Create an image with the specified dimensions
   $image = imagecreatefromjpeg("shirt.jpg");
 
   // Create a color
   $colorYellow = imageColorAllocate($image, 155,255,122);
 
   // Rotate
   $image=imagerotate($image,10, $colorYellow);
 
   // Set type of image and send the output
   header("Content-type: image/png");
   imagePng($image);
 
   // Release memory
   imageDestroy($image);
?>