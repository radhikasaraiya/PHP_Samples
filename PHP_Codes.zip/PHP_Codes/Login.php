<?php
if (isset($_POST['s1']))
{
	$user=$_POST['t1'];
	$pass=$_POST['t2'];
	if ($user=="php" && $pass=="easy")
	{
		header("Location:home.php?myuser=$user&mypass=$pass");
	}
	else
	{
		echo "sorry";
	}
}

?>



<form method="post">

	UserName <input type="text" name="t1" > <br/>
	Password <input type="text" name="t2" > <br/>
	<input type="submit" name="s1" value="Submit">
</form>