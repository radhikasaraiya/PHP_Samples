<h2>Student Details</h2>
<hr/>
<a href="class_Stud_Insert.php">Insert New Stud</a><br>
<hr/>
<?php
require_once("Class_Student.php");
if (isset($_REQUEST['rno']))
{
	$rno=$_REQUEST['rno'];
	$s1=new Student(0,"","","","");
	$s1->delete($rno);

}
$s1=new Student(0,"","","","");
$s1->showAll();
?>
