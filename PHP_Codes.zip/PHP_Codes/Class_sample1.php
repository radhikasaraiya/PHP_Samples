<?php
class rect
{
	//Data Member
	var $l,$b,$h;
	function __construct($l,$b,$h)
	{
		$this->l=$l;
		$this->b=$b;
		$this->h=$h;
	}
	function area()
	{
		//$a local variable
		$a=$this->l*$this->b;
		echo "Area is $a<Br>";
	}
	function vol()
	{
		$v=$this->l*$this->b*$this->h;
		return $v;
	}
}
if (isset($_POST['s1']))
{
$l=$_POST['t1'];
$b=$_POST['t2'];
$h=$_POST['t3'];
$r=new rect($l,$b,$h);
$r->area();
$ans=$r->vol();
echo "<Br>Volume is $ans";
}

?>

<form method="post">
	<table border="0">
			<tr>
			<td>Length</td>
			<td><input type="text" name="t1"></td>
			</tr>

			<tr>
			<td>Breath</td>
			<td><input type="text" name="t2"></td>
			</tr>
			
			<tr>
				<td>Heigth</td>
			<td><input type="text" name="t3"></td>
			</tr>

			<tr>
				
			<td><input type="submit" name="s1" value="submit"></td>
			</tr>

		</table>	
</form>