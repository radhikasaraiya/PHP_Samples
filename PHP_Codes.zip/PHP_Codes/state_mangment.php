<!-- query string -->
<!-- <?php
	//if(isset($_POST['s1']))
	{
		//$user=$_POST['t1'];
		//$a=$_POST['t2'];

		//if (strlen($user)>=5)
		//		header("Location:test.php?u=$user&age=$a");
		//else
		//		echo "Invalid";
	}
?>
 -->

<!-- Cookies -->
<!-- 
<?php

	if (isset($_POST['s1']))
	{
		setcookie("name",$_POST['nm'],time()+3600);
		setcookie("age",$_POST['age'],time()+3600);
	}

	if(isset($_POST['s2']))
	{
		if(isset($_COOKIE["name"]))
		{
			echo "Welcome  ".$_COOKIE["name"]."<br> Age ::".$_COOKIE["age"];
		}
		else
			echo "Invalid...!";
	}

	if (isset($_POST['s3']))
	{
		setcookie("name"," ",time()-3600);
		setcookie("age"," ",time()-3600);
		echo "Deleted Successfully...";
	}
?>
 -->
 <html>
<body>
	<form method="post" action="test2.php">
	Username:<input type="text" name="nm"><br><br>
	Age     :<input type="number" name="age"><br><br>
	<input type="submit" name="s1" value="Submit">
	<!-- <input type="submit" name="s2" value="Retrieve">
	<input type="submit" name="s3" value="Delete"> -->
</form>
</body>
</html>



