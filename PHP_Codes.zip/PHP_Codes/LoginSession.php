<?php
session_start();
if (isset($_POST['s1']))
{
	$user=$_POST['t1'];
	$pass=$_POST['t2'];
	if ($user=="php" && $pass=="easy")
	{
		$_SESSION["uname"]=$user;
		header("Location:homesession.php");  //Programmatic Navigation
	}
	else
	{
		echo "sorry";
	}
}

?>



<form method="post">

	UserName <input type="text" name="t1" > <br/>
	Password <input type="text" name="t2" > <br/>
	<input type="submit" name="s1" value="Submit">
</form>