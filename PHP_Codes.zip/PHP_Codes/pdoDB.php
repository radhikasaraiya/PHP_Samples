<?php
	try{
		$dsn="mysql:host=localhost; dbname=empdb"; // information required to connect DB.
		$user="root";
		$psd="";
		$connect=new PDO($dsn,$user,$psd);
	}

	catch(PDOException $e)
	{
		echo"error ".$e->getMessage();
	}
?>