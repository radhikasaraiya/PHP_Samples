<?php
/*$a="mscit";
$$a=5;
echo "$a";
echo $$a;
echo $mscit;
*/
$x="";
$y=0;
$ans=0;
if (isset($_POST['s1']))
{
	$x=$_POST['t1'];
	$y=$_POST['t2'];
	$ans=$x+$y;
	//echo "Ans is $ans <br>";
	//echo 'Ans is $ans'."<br>";
	//echo "Ans is ".$ans;
}
?>


<form method="post">
	No1 <input type="text" name="t1" value="<?php echo $x ?>" /><br/>
	No2 <input type="text" name="t2" value="<?php echo $y ?>" /><br/>
	Ans <input type="text" name="t3" value="<?php echo $ans ?>" /><br/>
	<input type="submit" name="s1">
</form>

