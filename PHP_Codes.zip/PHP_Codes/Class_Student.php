<?php
class Student
{
	var $rno,$sname,$fees,$course;
	

	function __construct($rno,$sname,$fees,$course)
	{
		$this->rno=$rno;
		$this->sname=$sname;
		$this->fees=$fees;
		$this->course=$course;
	}


	function Insert()
	{
	require_once("dbconnect.php");
	$sql = "INSERT INTO student values (0,'$this->sname','$this->course', 
		$this->fees)";
	if (mysqli_query($conn, $sql)) {
	  header("Location:Class_Show_Stud.php");
	} else {
	  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	}
	function Update()
	{
	require_once("dbconnect.php");
		$sql = "Update student set sname='$this->sname',fees=$this->fees, 
		course='$this->course'  where rno=$this->rno";
	if (mysqli_query($conn, $sql)) {
	  header("Location:Class_Show_Stud.php");
	} else {
	  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	}

	function delete($rno)
	{
			require_once("dbconnect.php");
			$delsql = "delete from student where rno=$rno";
			$res=mysqli_query($conn, $delsql);
			header("Location:Class_Show_Stud.php");
	}

	function search($rno)
	{
		require_once("dbconnect.php");
			$sql = "select *  from student where rno=$rno";
			$res=mysqli_query($conn, $sql);
			$row=mysqli_fetch_array($res);
			return $row;
	}

	function showAll()
	{
		require_once("dbconnect.php");
		$sql = "select * from student";
		$res=mysqli_query($conn, $sql);
		echo "<table border=1>";
		echo "<tr>";
		echo "<th>RollNo</th>";
		echo "<th>Name</th>";
		echo "<th>Semester</th>";
		echo "<th>course</th>";
		echo "<th>Delete</th>";
		echo "<th>Edit</th>";
		echo "</tr>";
		while ($row=mysqli_fetch_assoc($res))
		{
			$rno=$row['Rno'];
			echo "<tr>";
			echo "<td>".$row['Rno']."</td>";
			echo "<td>".$row['SName']."</td>";
			echo "<td>".$row['Fees']."</td>";
			echo "<td>".$row['Course']."</td>";
			echo "<td><a href=Class_Show_Stud.php?rno=$rno>Delete</a></td>";
			echo "<td><a href=Class_Stud_Edit.php?erno=$rno>Edit</a></td>";
			echo "</tr>";
		}
	}

}


?>