<?php
if (isset($_POST['s1']))
{
	$user=$_POST['t1'];
	$age=$_POST['t2'];
	header("Location:result1.php?u=$user");
}

?>





<form method="post">
	Name <input type="text" name="t1" ><br/>
	Age <input type="text" name="t2" ><br/>
	<input type="submit" name="s1" value="Submit" ><br/>
</form>