<?php
session_start();
if (isset($_POST['s1']))
{
	$nm=$_POST['t1'];

	if (isset($_SESSION["data"]))
		$ar=$_SESSION["data"];
	else
		$ar=array();
	
	array_push($ar, $nm);
	print_r($ar);
	$_SESSION["data"]=$ar;

}
?>
<form method="post">
Name <input type="text" name="t1"> </br>
<input type="submit" name="s1">
</form>