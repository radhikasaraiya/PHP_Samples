<?php

$xml = simplexml_load_file('emp.xml');

echo '<h2>Employees Listing</h2>';

$list = $xml->record;

echo "Total Records ".count($list)."<br>";

require("dbconnect.php");
for ($i = 0; $i < count($list); $i++) {

    echo '<b>Employees ID:</b> ' . $list[$i]->attributes()->empno . '<br>';

    echo 'Name: ' . $list[$i]->name . '<br>';

    echo 'Position: ' . $list[$i]->position . '<br>';

    echo 'Salary: ' . $list[$i]->Salary . '<br><br>';

    	// $eno=$list[$i]->attributes()->empno ;
    	// $ename=$list[$i]->name;
    	// $pos=$list[$i]->position;
    	// $sal=$list[$i]->Salary;
    	// $sql="inseert into emp values($eno,$ename,$pos,$sal)";
    	// mysqli_query($conn,$sql);


}
?>