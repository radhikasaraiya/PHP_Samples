<?php 
require_once( 'dbconnect.php');
$xml=simplexml_load_file('student.xml');
$list=$xml->student;

for($i=0;$i<count($list);$i++)
{
	echo $list[$i]->attributes()->id;
	echo $list[$i]->name;
	echo $list[$i]->course;
	echo $list[$i]->clg;
	echo "<br>";

	$rno=$list[$i]->attributes()->id;
	$nm=$list[$i]->name;
	$course=$list[$i]->course;
	$clg=$list[$i]->clg;
	$qry="insert into xmldata values($rno,'$nm','$course','$clg')";
	//echo $qry."<br>";

	$r=mysqli_query($conn,$qry);

	if($r==1)
		echo "$i record is inserted<br>";
	else
		echo "Error<br>";
 }
?>
