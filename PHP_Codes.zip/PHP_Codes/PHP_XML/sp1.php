<?php
$xml = simplexml_load_file("books.xml") 
//The simplexml_load_file() function converts an XML document to an object.
       or die("Error: Cannot create object");
	   
foreach($xml->children() as $books){
	foreach($books->children() as $book => $data){	
	//The children() function finds the children of a specified node.
	  echo $data->id;
	  echo $data->title;
	  echo $data->author;
	  echo "<br />";
	}
}

?>