<?php
$xmlDoc = new DOMDocument(); 
//Represents an entire HTML or XML document; serves as the root of the document tree.
$xmlDoc->load("notes.xml");
//The DOMDocument::load() function is an inbuilt function in PHP which is used to load an XML document from a file.
//Syntax:
//mixed DOMDocument::load( string $filename, int $options = 0 )
//Parameters: This function accepts two parameters as mentioned above and described below:

//$filename: This parameter holds the path to the XML document.
print $xmlDoc->saveXML();
//DOMDocument::saveXML — Dumps the internal XML tree back into a string


?> 