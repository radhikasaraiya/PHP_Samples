<?php
$xml = simplexml_load_file("cars.xml") 
       or die("Error: Cannot create object");
	   
foreach($xml->children() as $cars){
	foreach($cars->children() as $car => $data){
		echo "<br><h1>Car Details</h1><br>";
	  echo $data->manufacture['country']."<br/>";
	  echo $data->manufacture."<br/>";
	  echo $data->type."<br/>";
	  echo $data->model."<br/>";
	  
	  echo "<br/><br />";
	}
}

?>