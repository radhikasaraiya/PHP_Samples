<?php
$conn=mysqli_connect("localhost","root","","firstsample"); //connection string -server,username,password
//$db=mysqli_select_db($con,"firstsample"); //selection of server-connection,name of db

if (!$conn)
{
	die("Connection failed".mysqli_error());
}
// if (!$db)
// {
// 	die("Error in DataBase".mysqli_error());
// }
?>