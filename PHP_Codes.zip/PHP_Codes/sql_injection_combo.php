<?php
$db_connection = mysqli_connect("localhost", "root", "", "firstsample");
//$username=Jame's
$username = mysqli_real_escape_string($db_connection, "Jame's");
$password = mysqli_real_escape_string($db_connection, "Eas'ie--s");
$query = "SELECT * FROM users WHERE username = '" . $username. "' AND password = '" . $password . "'"; 
echo $query;
?>		
	
