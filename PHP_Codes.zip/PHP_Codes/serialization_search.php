<?php
include 'serialDB.php';
$ar=array();
if(isset($_POST['s2']))
{
	$rno=$_POST['t1'];

	$sql="select *from testTB where rno='$rno'";
	$res=mysqli_query($con,$sql);

	$row=mysqli_fetch_assoc($res);
	
		$temp=$row['data'];
		$ar=unserialize($temp);

		echo "NAME : ".$ar[0];
		echo "SEM  : ".$ar[1];
	
}
?>
<html>
<head>
</head>
<body>
	
<form method="post">
<h3>Enter the Rno:</h3>
<input type="text" name="t1"><br><br>
<input type="submit" name="s2" value="Search">
</form>
</body>
</html>