<?php
include 'database.php';

if(isset($_REQUEST['id']))
{
$filetmppath=$_FILES['upload_file']['tmp_name'];
$dest="./upload/".$_FILES['upload_file']['name'];

$fp=fopen($dest,"r");

$filetype=filetype($dest);

header("Content-Type:".$filetype);
header("Content-Length:".filesize($dest));
readfile($dest);
}
?>


<?php
include"database.php";
$qry="select *from empinfo where id=".$_REQUEST['id'];
//echo $qry;
$res=mysqli_query($con,$qry);
$row=mysqli_fetch_array($res);

if(isset($_POST['s2']))
{
	$eid=$_REQUEST['id'];
	$ename=$_POST['enm'];
	$esal=$_POST['sal'];
	$d=$_POST['deptcombo'];

$filetmppath=$_FILES['upload_file']['tmp_name'];
$dest="./upload/".$_FILES['upload_file']['name'];
echo $dest;
move_uploaded_file($filetmppath, $dest);
$upqry="update empinfo set name='$ename',salary=$esal,upload_pic='$dest',dept_id=$d where id=$eid";
//echo $upqry;
	 $u=mysqli_query($con,$upqry);

 if($u==1)
  	header('Location:showEmp(db).php');
 }
?>
<form method="post" enctype="multipart/form-data">
Id:<input type="number" name="eid" readonly value='<?php echo $row[0]; ?>'><br><br>
Name:<input type="text" name="enm" value='<?php echo $row[1]; ?>'><br><br>
City:    <select name="city">
			<option>--Select City--</option>
			<option value="surat"<?php if ($row[2]=='surat') echo"selected"; ?> >Surat</option>

			<option value="abad" <?php if ($row[2]=='abad') echo"selected"; ?>>Ahemdabad</option>
			<option value="vadodara" <?php if ($row[2]=='vadodara') echo"selected"; ?>>Vadodara</option>
			<option value="mumbai" <?php if ($row[2]=='mumbai') echo"selected"; ?>>Mumbai</option>
		</select><br><br>

Gender  :<input type="radio" name="gender" value="male" <?php if ($row[3]=='male') echo"checked"; ?> >Male

<input type="radio" name="gender" value="female" <?php if ($row[3]=='female') echo"checked"; ?> >Female<br><br>

Select Shift :<input type="checkbox" name="c1" value="day" <?php if ($row[4]=='day') echo"checked"; ?>>Day
			<input type="checkbox" name="c1" value="night" <?php if ($row[4]=='night') echo"checked"; ?>>Night 	<br><br>

Salary : <input type="number" name="sal" value='<?php echo $row[5]; ?>'><br><br>

Picture:<input type="file" name="upload_file" value='<?php echo $row[6]; ?>'>
<img src='<?php echo $row[6]; ?>'height="50" width="50"><br>
Dept:<select name="deptcombo" value="<?php echo $row[7]; ?>">
	<option>---Select Dept---</option>
	<?php
	 	$dq="select *from depttb";
	 	$dres=mysqli_query($con,$dq);

	 	while($drow=mysqli_fetch_array($dres))
	 	{
	 	?>
	 	<option value="<?php echo $drow[0]; ?>" 
	 		<?php if($drow[0]==$row[7]) 
	 					echo "selected";
	 		 ?> > <?php  echo $drow[1]; ?></option>	
	 	<?php	 
	 	}
	 	?>
	</select><br>
<input type="submit" name="s2" value="Update">
</form>