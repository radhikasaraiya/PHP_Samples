<?php

if (isset($_POST['s1']))
{
$ans="";

	if (isset($_POST['c1']))	
		$ans=$ans.",".$_POST['c1'];
	if (isset($_POST['c2']))	
		$ans=$ans.",".$_POST['c2'];
	if (isset($_POST['c3']))	
		$ans=$ans.",".$_POST['c3'];
	
	echo " You selected $ans";

}
?>



<form method="post">

<table border="0">
		<tr>
			
			<td>
				<input type="checkbox" name="c1" value="Square">Square <br>
				<input type="checkbox" name="c2" value="Cube">Cube <br>
				<input type="checkbox" name="c3" value="Root">Root <br>
			</td>
		</tr>
		
		<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
</form>
