<html>
<?php


if (isset($_GET['t1']))
{
$nm=$_GET['t1'];
echo "You Entered Your Name $nm";
	
}
?>



<form>
	Name <input type="text" name="t1"><br/>
	<input type="submit" name="s1">
</form>
</html>		
<?php
include_once("links.php");
?>
