<?php

if (isset($_POST['s1']))
{
$ch=$_POST['c1'];
$ans="";
//echo $ch;
print_r($ch);
echo "<br>Checkbox values <br>";
foreach($ch as $x){
	echo $x."<br>";
	$ans=$ans.",".$x;
}
echo "<br>Ans is $ans";
}
?>
<form method="post">
<table border="0">
		<tr>
			
			<td>
				<input type="checkbox" name="c1[]" value="Square">Square <br>
				<input type="checkbox" name="c1[]" value="Cube">Cube <br>
				<input type="checkbox" name="c1[]" value="Root">Root <br>
			</td>
		</tr>
		
		<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
</form>
