<?php
/*
 class person
 {
	private $fname;
	private $lname;


	public function setName($fname,$lname)
	{
		$this->fname=$fname;
		$this->lname=$lname;
	}

	public function show()
	{
		echo "My Name is ".$this->fname." ".$this->lname;
	}
}

$p=new person;
$p->setName("Hinal","Acharya");
$p->show();
?>*/
/**
 * 
 */
class vehicle 
{
	protected $name;
	public $n=5;
	
	public function __construct($name)
	{
		echo "Parent class constructor is called.<br>";
		$this->name=$name;
	}

	public function __destruct()
	{
		echo "Parent class destructor is called.<br>";
	}

	public function start()
	{
		echo $this->name." is start...<br>";
	}

		public function drive() 	
	{
        echo "Vehicle class drive method.<br/>";
    }
}

class car extends vehicle
{	

	
	public function __construct($name)
	{
		parent::__construct($name);
		echo "child class constructor is called.<br>";
		$this->name=$name;
	}

	public function __destruct()
	{
		echo "child class destructor is called.<br>";
	}

	public function drive()
	{
		echo "I have a car named ".$this->name;
		echo "<br> child class drive method is called.";
	}
}

$c=new Car("Mercedes benz");
$c->start();
$c->drive();




















