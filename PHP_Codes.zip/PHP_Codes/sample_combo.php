<?php

if (isset($_POST['s1']))
{
$ans=$_POST['cmb'];
echo " You selected $ans";

}
?>
<form method="post">

<table border="0">
		<tr>
			
			<td>
				<select name="cmb">
				<option value="select">---Select---</option>
				<option value="surat">Surat</option>
				<option value="mumbai">Mumbai</option>
				<option value="vapi">Vapi</option>	
				</select>
			</td>
		</tr>
		
		<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
</form>
