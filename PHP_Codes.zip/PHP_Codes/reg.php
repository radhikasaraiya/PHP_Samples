<form method="post" action="msubmit.php">

<table border="0">
		<tr>
			<tr>
			<td>Login</td>
			<td><input type="text" name="t1"></td>
			</tr>
			<tr>
			<td>Password</td>
			<td><input type="Password" name="t2"></td>
			</tr>
			<tr>
			
			<td>
				<input type="radio" checked name="r1" value="M">Male <br>
				<input type="radio" name="r1" value="F">Female <br>
			</td>
		</tr>
<tr>
		<td>Hobbies</td>	
			<td>
				<input type="checkbox" name="c1[]" value="music">Music <br>
				<input type="checkbox" name="c1[]" value="swimming">Swiming <br>
				<input type="checkbox" name="c1[]" value="Cricket">Cricket <br>
			</td>
		</tr>

		<tr>
			<td>City</td>
			<td>
				<select name="cmb">
				<option value="select">---Select---</option>
				<option value="surat">Surat</option>
				<option value="mumbai">Mumbai</option>
				<option value="vapi">Vapi</option>	
				</select>
			</td>
		</tr>
		
		<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
</form>
