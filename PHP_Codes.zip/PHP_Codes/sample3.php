<html>
<?php

if (isset($_POST['t1']))
{
	$nm=$_POST['t1'];
	echo "You Entered Your Name $nm";
}
?>

<form method="POST">
	Name <input type="text" name="t1"><br/>
	<input type="submit" name="s1">

</form>
</html>		

<?php
//include_once("links.php");
?>