<?php
$ans=0;
$no=0;
if (isset($_POST['s1']))
{
	$no=$_POST['t1'];
	$ch=$_POST['r1'];
	
	if ($ch=="S")
	{
		$ans=$no*$no;
	}
	else
	 {
		$ans=$no*$no*$no;
	
	}
	//echo "I selected $ch";
}
?>



<form method="post">

<table border="0">
		<tr>
			<td>No</td>
			<td><input type="text" name="t1" value="<?php echo $no ?>"></td>
		</tr>
		<tr>
			
			<td>
				<input type="radio" name="r1" value="S">Square <br>
				<input type="radio" name="r1" value="C">Cube <br>
			</td>
		</tr>
		
		<tr>
			<td>Ans</td>
	<td><input type="text" name="t2" value="<?php echo $ans ?>" ></td>
		</tr>
		<tr>
		
			<td colspan="2" align="center"><input type="submit" name="s1" value="Submit"></td>
		</tr>
		
	</table>
</form>
