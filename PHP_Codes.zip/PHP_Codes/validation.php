<?php
$nmerror=$mailerror=$passerror=$cpwderror=$gerror=$herror="";
$nm=$mail=$pwd=$cpsd=$gen=$h="";

if(isset($_POST['s1']))
{
	$nm=$_POST['enm'];
	$mail=$_POST['mail'];
	$pwd=$_POST['psd'];
	$cpsd=$_POST['cpsd'];
	$gen=$_POST['gender'];
	$h=$_POST['c1'];

	// name
	if(empty($nm))
		$nmerror="Name is Required";
	else
	{
		
		if(!(preg_match("/^[a-zA-Z]*$/", $nm)))
			$nmerror="Name can Contain Alphabets Only. ";
		else
			$nmerror="";
	}

	if(empty($mail))
		$mailerror="Mail is Required";
	else
	{
		if(!filter_var($mail,FILTER_VALIDATE_EMAIL))
			$mailerror="Invalid Mail Foramte.";
	}

	if(empty($pwd))
		$passerror="PassWord is Required";

	
	if(empty($cpsd))
		$cpwderror="Confirm PassWord is Also Required.";
	else
	{
		if ((strcmp($pwd,$cpsd)!=0))
		$cpwderror="Confirm password should match PassWord";
	}

	if(empty($gen))
		$gerror="Please select the Gender";

	if(empty($h))
		$herror="Select Hobbies";



}
?>
<html>
<head>
</head>
<body>
<form method="post">
	
	<h3><i>Form Validation</i></h3>
	Name :<input type="text" name="enm" value="<?php echo $nm; ?>">	
	<div style="color: red"><?php echo "$nmerror <br>";?></div>
	<br><br>

	Email:<input type="text" name="mail" value="<?php echo $mail; ?>">
		<div style="color: red"><?php echo "$mailerror <br>";?></div><br><br>

	PassWord:<input type="password" name="psd" value="<?php echo $pwd; ?>">
	<div style="color: red"><?php echo "$passerror <br>";?></div><br><br>
<br><br>
	Confirm PassWord:<input type="password" name="cpsd" value="<?php echo $cpsd; ?>">
	<div style="color: red"><?php echo "$cpwderror <br>"; ?></div><br><br>

Gender:<input type="radio" name="gender" value="male" <?php if($gen=="male") echo" checked" ?> >Male
		<input type="radio" name="gender" value="female" <?php if($gen=="female") echo" checked" ?>>Female
		<div style="color: red"><?php echo "$gerror <br>"; ?></div><br><br>

Hobbies :<input type="checkbox" name="c1[0]" value="reading" <?php if(isset($_POST['c1'][0])) echo "checked"; ?> >Reading
		<input type="checkbox" name="c1[1]" value="cricket" <?php if(isset($_POST['c1'][1])) echo "checked"; ?>>Cricket  
		<div style="color: red"><?php echo "$herror <br>"; ?></div><br><br>

<input type="submit" name="s1" value="Submit">		

</form>
</body>
</html>

<?php
echo "<h2> Input is </h2>";
echo "$nm <br>";
echo "$mail <br>";
echo "$gen <br>";
print_r($h);
?>