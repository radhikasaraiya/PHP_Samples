<?php


$x="Aa";
$y=34;
$z=34.54;
$p=NULL;
echo $x."<BR>";

echo $y."<BR>";

echo $z."<BR>";

echo "I am null variable ".$p."<BR>";
?>
<?php
//include_once("links.php");
?>