<?php

$uname=$_REQUEST["myuser"];
$pass=$_REQUEST["mypass"];
echo "Hello $uname ";
echo "Pass is $pass";
?>
<body bgcolor="cyan">
	

</body>