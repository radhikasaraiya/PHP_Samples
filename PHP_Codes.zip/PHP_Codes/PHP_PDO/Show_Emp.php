<?php

//require_once("dbconnect.php");
$host = "mysql:host=localhost;dbname=mscitdb";
$user = "root";
$pass = "";
$pdo = new PDO($host, $user, $pass);

if (isset($_REQUEST['eno']))
{
	$eno=$_REQUEST['eno'];
	$dsql="delete from emp where eno=$eno";
	//mysqli_query($conn, $dsql);
	$nrows=$pdo->exec($dsql);
	echo "Rows Deleted $nrows";
}
//$res=mysqli_query($conn, $sql);
$sql = "select eno,ename,salary,gender,skills,jdate,dname from emp e,dept d where e.dno=d.dno";
//$res=mysqli_query($conn, $sql);
$res = $pdo->query($sql);
$rows = $res->fetchAll(PDO::FETCH_ASSOC) ;//PDO::FETCH_NUM);

echo "<center>";
echo "<table border=1>";
echo "<tr>";
echo "<th>Empno</th>";
echo "<th>Name</th>";
echo "<th>Sal</th>";
echo "<th>DeptName</th>";
echo "<th>Gender</th>";
echo "<th>Skills</th>";
echo "<th>JoinDate</th>";
echo "</tr>";
foreach($rows as $row)
{
	
	
		echo "<tr>";
		$eno=$row['eno'];
	echo "<td>".$row['eno']."</td>";
	echo "<td>".$row['ename']."</td>";
	echo "<td>".$row['salary']."</td>";
	echo "<td>".$row['dname']."</td>";
	echo "<td>"	.$row['gender']."</td>";
	echo "<td>".$row['skills']."</td>";
	echo "<td>".$row['jdate']."</td>";
echo "<td><a href=Show_Emp.php?eno=$eno>Delete</a></td>";
echo "<td><a href=Edit_Emp.php?eno=$eno>Edit</a></td>";

	echo "</tr>";

}
echo "</table>";
echo "</center>";
?>