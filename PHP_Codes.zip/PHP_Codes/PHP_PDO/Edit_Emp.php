<?php
$host = "mysql:host=localhost;dbname=mscitdb";
$user = "root";
$pass = "";
$pdo = new PDO($host, $user, $pass);


	$eno="";
	$ename="";
	$sal="";
	$dno="";
	$gender="";
	$skills="";
	$jdate="";
$gen_ar=array("Male","Female");
$skills_ar=array("PHP","JAVA","RDBMS");
//require_once("dbconnect.php");

if (isset($_POST['s1']))
{
	 $eno=$_POST['t0'];
	 $ename=$_POST['t1'];
	 $sal=$_POST['t2'];
	 $gen=$_POST['r1'];
	 $dno=$_POST['cmbdept'];
	 $jdate=$_POST['t3'];
	 echo $jdate;
	// $date1 = DateTime::createFromFormat('m/d/Y', $jdate);
	 //$newjdate= $date1->format('Y-m-d');
	 $ar=$_POST['c1'];
	 $sk=implode(",", $ar);
	 echo $ename."<br>";
	 echo $sal."<br>";
	 echo $gen."<br>";
	 echo $dno."<br>";
	 echo $jdate."<br>";
	 echo $sk."<br>";
	 
$sql = "update emp set 
		ename='$ename', 
		salary='$sal',
		gender='$gen',
		dno='$dno',
		jdate='$jdate' ,
		skills='$sk' where eno='$eno'";
		$nrows=$pdo->exec($sql);
	if ($nrows>0) {
	  header("Location:Show_Emp.php");
	} else {
	  echo "Error: " . $sql . "<br>"  ;
	}
	}

if (isset($_REQUEST['eno']))
{
	$eno=$_REQUEST['eno'];
	$sql = "select * from emp e where eno=$eno";
	$res=$pdo->query($sql);
	$row = $res->fetch(PDO::FETCH_ASSOC) ;//PDO::FETCH_NUM);
	//$res=mysqli_query($conn, $sql);
	
	$eno=$row['eno'];
	$ename=$row['ename'];
	$sal=$row['salary'];
	$dno=$row['dno'];
	$gender=$row['gender'];
	$skills=$row['skills'];
	$jdate=$row['jdate'];
	
echo $skills;
}
?>

<form method="post">
	<table border="0">
			<tr>
			<td>EmpNo </td>
			<td><input type="text" name="t0" 
				value='<?php echo $eno; ?>' ></td>
			</tr>

			<tr>
			<td>EmpName </td>
			<td><input type="text" name="t1" value='<?php echo $ename; ?>'></td>
			</tr>

			<tr>
			<td>Sal</td>
			<td><input type="text" name="t2"
				value='<?php echo $sal; ?>'</td>
			</tr>
			
			<tr>
				<td>Deptno</td>
			<td>
				<select name=cmbdept> 
<option value="0">--select--</option>
				<?php

$sql = "select * from dept";
//$res=mysqli_query($conn, $sql);
$res = $pdo->query($sql);

$rows = $res->fetchAll(PDO::FETCH_ASSOC) ;//PDO::FETCH_NUM);
//$res=mysqli_query($conn, $sql);
foreach($rows as $row)
{
if ($dno==$row['dno'])
{
?>
<option selected value="<?php echo $row['dno'] ;?>"><?php echo $row['dname'] ;?></option>

<?php
}	
else
{
?>
<option value="<?php echo $row['dno'] ;?>"><?php echo $row['dname'] ;?></option>
<?php
}
}
?>
</select>
			</td>
			</tr>
			<tr>
				<td>Gender</td>
			<td>
				<?php
				foreach ($gen_ar as $key) 
				{
					if ($key==$gender)
					{
			     ?>
<input type=radio  checked name=r1 value=<?php echo $key ;?> /><?php echo $key ;?> 

<?php
	}
	else
	{
	?>
	<input type=radio name=r1 value=<?php echo $key ;?> /><?php echo $key ;?> 
	
	<?php
	}
	}
	?>

		<br/>
				 
				


			</td>
			</tr>
			<tr>
			<tr>
			<td>Skills</td>
			<td><?php
				foreach ($skills_ar as $key) {
				$tar=explode(",", $skills);
				if (in_array($key,$tar))
				{
				?>
<input type=checkbox checked name=c1[] value=<?php echo $key ;?> /><?php echo $key ;?> 
				<?php
				}
				else
				{
				?>

		<input type=checkbox name=c1[] value=<?php echo $key ;?> /><?php echo $key ;?> 
		<br/>
				<?php	
				}
				}
				?></td>
			</tr>

			<tr>
				<td>JoinDate</td>
		<td><input type="date" name="t3" 
				value='<?php echo $jdate ; ?>'
			></td>
			</tr>
			<td><input type="submit" name="s1" value="submit"></td>
			</tr>

		</table>	
</form>