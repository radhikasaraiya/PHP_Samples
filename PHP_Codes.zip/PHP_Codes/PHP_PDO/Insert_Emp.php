<?php

$gen=array("Male","Female");
$skills=array("PHP","JAVA","RDBMS");

$host = "mysql:host=localhost;dbname=mscitdb";
$user = "root";
$pass = "";
$pdo = new PDO($host, $user, $pass);
//require_once("dbconnect.php");

if (isset($_POST['s1']))
{
	 $ename=$_POST['t1'];
	 $sal=$_POST['t2'];
	 $gen=$_POST['r1'];
	 $dno=$_POST['cmbdept'];
	 $jdate=$_POST['t3'];
	 echo $jdate;
	// $date1 = DateTime::createFromFormat('m/d/Y', $jdate);
	 //$newjdate= $date1->format('Y-m-d');
	 $ar=$_POST['c1'];
	 $sk=implode(",", $ar);
	 echo $ename."<br>";
	 echo $sal."<br>";
	 echo $gen."<br>";
	 echo $dno."<br>";
	 echo $jdate."<br>";
	 echo $sk."<br>";

$sql = "INSERT INTO emp values (0,'$ename',$sal,$dno, '$gen','$sk','$jdate')";

echo $sql;
$id = 12;

$nrows = $pdo->exec($sql);

echo "The statement affected $nrows rows\n";

	if ($nrows>0) {
	  header("Location:Show_Emp.php");
	} else {
	  echo "Error: " . $sql . "<br>" ;
	}
}
//mysqli_close($conn);
?>
<form method="post">
	<table border="0">
		
			<tr>
			<td>EmpName </td>
			<td><input type="text" name="t1"></td>
			</tr>

			<tr>
			<td>Sal</td>
			<td><input type="text" name="t2"></td>
			</tr>
			
			<tr>
				<td>Deptno</td>
			<td>
				<select name=cmbdept> 
<option value="0">--select--</option>
				<?php
$sql = "select * from dept";
$res = $pdo->query($sql);

$rows = $res->fetchAll(PDO::FETCH_ASSOC) ;//PDO::FETCH_NUM);
//$res=mysqli_query($conn, $sql);
foreach($rows as $row)
{
	
?>
<option value="<?php echo $row['dno'] ;?>"><?php echo $row['dname'] ;?></option>
<?php
}
?>
</select>
			</td>
			</tr>
			<tr>
				<td>Gender</td>
			<td>
				<?php
				foreach ($gen as $key) {
				?>
		<input type=radio name=r1 value=<?php echo $key ;?> /><?php echo $key ;?> 
		<br/>
				<?php	
				}
				?>
			</td>
			</tr>
			<tr>
			<tr>
			<td>Skills</td>
			<td><?php
				foreach ($skills as $key) {
				?>
		<input type=checkbox name=c1[] value=<?php echo $key ;?> /><?php echo $key ;?> 
		<br/>
				<?php	
				}
				?></td>
			</tr>

			<tr>
				<td>JoinDate</td>
		<td><input type="date" name="t3" ></td>
			</tr>
			<td><input type="submit" name="s1" value="submit"></td>
			</tr>

		</table>	
</form>