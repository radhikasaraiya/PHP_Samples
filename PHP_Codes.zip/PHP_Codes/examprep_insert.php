<?php
	require 'prep_database.php';
	if(isset($_POST['submit']))
	{
		$nm=$_POST['nm'];
		$sal=$_POST['salary'];
		$gen=$_POST['gender'];
		$shift=$_POST['c1'];
		$temp=$_FILES['upload_file']['temp_name'];
		$dest="./upload/".$_FILES['upload_file']['name'];

		move_uploaded_file($temp, $dest);

		$sql="insert into test1(id,name,salary,gender,shift,picture)values('NULL','$nm','$sal','$gen','$shift','$dest')";

		$result=mysqli_query($con,$sql);

		if($result==1)
			header('Location:examprep_show.php');
		else
			echo "error";
	}

 ?>

<html>
<body>

<form method="post" enctype="multipart/form-data">
Name :<input type="text" name="nm" required="true"><br><br>
Salary:<input type="number" name="salary" required="true"><br><br>
Gender:<input type="radio" name="gender" required value="male">Male
<input type="radio" name="gender" required value="female">Female <br><br>
Shift:<input type="checkbox" name="c1" value="day">Day
<input type="checkbox" name="c1" value="night">Night<br><br>
Picture: <input type="file" name="upload_file"><br><br>

<input type="submit" name="submit" value="INSERT">
</form>
</body>
</html>